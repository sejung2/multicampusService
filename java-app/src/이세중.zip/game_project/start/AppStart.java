package game_project.start;

public class AppStart {
    public static void main(String[] args) {
        Start start = new Start(); // Start 클래스의 인스턴스를 생성
        start.run(); // run 메서드를 호출하여 프로그램을 시작
    }
}
